﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Dostya",
                Age = 43,
                Race = Character.RaceType.Cybran,
                Health = 100,
                Lives = 3,
                FactionAcceptence = 10,
                ThreatLevelModifyer = 10,
                LocationId = 0
            };
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "XDXDXDXD"
            };
        }

        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);

            //
            // row 1
            //
            gameMap.MapLocations[0, 0] = new Location()
            {
                Id = 4,
                Name = "Sleeping Quarters",
                Description = "This is your faciton's sleeping quarters and where you will return every in game day to rest your characeter," +
                  "This is one of the only safe place in the game. (If your threat level is high you cannot be attacked here) ",
                Accessible = true,
                ThreatLevel = 0
            };
            gameMap.MapLocations[0, 1] = new Location()
            {
                Id = 1,
                Name = " Headquarters",
                Description = "This is your faciton's diplomatic headquarters and where you will return every in game day to rest your characeter," +
                  "This is the only safe place in the game. (If your threat level is high you cannot be attacked here) " +
                  "This is where you will get your diplomatic Missions",
                Accessible = true,
                ThreatLevel = 0
            };

            //
            // row 2
            //
            gameMap.MapLocations[1, 1] = new Location()
            {
                Id = 2,
                Name = "Transit Station",
                Description = "This is the Cybran transit station that will bring you to the meeting place or to the markets or shipyards that ",
                Accessible = true,
                ThreatLevel = 10
            };
            gameMap.MapLocations[1, 2] = new Location()
            {
                Id = 2,
                Name = "Epitoria's Reading Room",
                Description = "Queen Epitoria, the Torian Monarh of the 5th Dynasty, was know for her passion for " +
                "galactic history. The room has a tall vaulted ceiling, open in the middle  with four floors of wrapping " +
                "balconies filled with scrolls, texts, and infocrystals. As you enter the room a red fog desends from the ceiling " +
                "and you begin feeling your life energy slip away slowly until you are dead.",
                Accessible = false,
                ThreatLevel = 50,
                ModifyLives = -1,
                RequiredExperiencePoints = 40                
            };

            //
            // row 3
            //
            gameMap.MapLocations[2, 0] = new Location()
            {
                Id = 3,
                Name = "Xantoria Market",
                Description = "The Xantoria market, once controlled by the Thorian elite, is now an open market managed " +
                "by the Xantorian Commerce Coop. It is a place where many races from various systems trade goods." +
                "You purchase a blue potion in a thin, clear flask, drink it and receive 50 points of health.",
                Accessible = false,
                ThreatLevel = 20,
                ModifyHealth = 50,
                Message = "Traveler, our telemetry places you at the Xantoria Market. We have reports of local health potions."
            };
            gameMap.MapLocations[2, 1] = new Location()
            {
                Id = 4,
                Name = "Cybran Headquarters",
                Description = "The cybran headquarters where you will meet the leader of the cybrans. Docter Brackman.",
                Accessible = true,
                ThreatLevel = 10
            };

            return gameMap;
        }
    }
}
