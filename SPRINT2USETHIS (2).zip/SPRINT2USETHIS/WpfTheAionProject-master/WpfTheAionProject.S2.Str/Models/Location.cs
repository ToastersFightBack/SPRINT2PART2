﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTheAionProject.Models
{
    public class Location
    {
        #region FEILDS
        private int _id;
        private string _name;
        private string _description;
        private bool _accessible;
        private int _modifyExperincePoints;


        public int ModifyExperencePoints
        {
            get { return _modifyExperincePoints; }
            set { _modifyExperincePoints = value; }
        }


        public bool Accessible
        {
            get { return _accessible; }
            set { _accessible = value; }
        }


        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }


        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        #endregion

        #region PROPERTIES

        #endregion

        #region CONSTRUCTORS

        #endregion

        #region METHODS
        public override string ToString()
        {

            return _name;
        }
        #endregion
    }
}
